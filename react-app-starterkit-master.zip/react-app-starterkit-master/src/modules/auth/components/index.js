import AuthPage from './AuthPage';
import Login from './Login';
import Register from './Register';

export {
  AuthPage,
  Login,
  Register,
};
