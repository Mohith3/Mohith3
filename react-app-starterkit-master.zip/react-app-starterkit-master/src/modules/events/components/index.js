import EventPage from './EventPage';
import EventsPage from './EventsPage';

export {
  EventsPage,
  EventPage,
};
